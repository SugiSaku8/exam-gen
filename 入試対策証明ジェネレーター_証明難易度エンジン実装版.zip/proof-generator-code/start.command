#!/bin/zsh
set -e
cd "$(dirname "$0")"
PORT=8000

if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 が見つかりません。macOS のターミナルで python3 を利用できる状態にしてください。"
  read -r
  exit 1
fi

if lsof -iTCP:${PORT} -sTCP:LISTEN >/dev/null 2>&1; then
  echo "ポート ${PORT} はすでに使用されています。http://127.0.0.1:${PORT}/ を開きます。"
  open "http://127.0.0.1:${PORT}/index.html"
  exit 0
fi

python3 -m http.server "$PORT" --bind 127.0.0.1 >/tmp/shizuoka-proof-generator-http.log 2>&1 &
SERVER_PID=$!
trap 'kill "$SERVER_PID" 2>/dev/null || true' EXIT INT TERM
sleep 0.5
open "http://127.0.0.1:${PORT}/index.html"

echo "入試対策証明ジェネレーターを起動しました。"
echo "終了する場合はこのターミナルを閉じるか Ctrl+C を押してください。"
wait "$SERVER_PID"
