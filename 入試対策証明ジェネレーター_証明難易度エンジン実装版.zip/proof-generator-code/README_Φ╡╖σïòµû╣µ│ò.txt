入試対策証明ジェネレーター 起動方法

1. Macでは「start.command」をダブルクリックしてください。
2. ブラウザで http://127.0.0.1:8000/index.html が開きます。
3. 直接 index.html をダブルクリックして開く方法では、ES Modules の読み込み制限により画面が表示されない場合があります。

保存について
- 「PCに保存」: 問題データ全体をJSONファイルとして保存します。
- 「ブラウザに保存」: 同じ問題を localStorage と Cookie の両方へ保存します。
- ロード時は localStorage を優先し、localStorage にない場合は Cookie から復元します。
- Cookieは容量制限があるため、大きな問題データではlocalStorageのみ保存される場合があります。
