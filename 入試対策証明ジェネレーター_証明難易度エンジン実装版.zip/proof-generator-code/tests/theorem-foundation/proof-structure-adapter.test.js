import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import '../../js/theorem-catalog.js';
import '../../js/proof-rules.js';
import { parseAtomicStatement, parseAtomicStatements, auditStructuredProof } from '../../js/proof_structure_adapter.js';
import { auditGeneratedProblem } from '../../js/proof_audit.js';

const loadYear = async (year) => JSON.parse(await readFile(new URL(`../../data/${year}.json`, import.meta.url), 'utf8'));

test('parses only explicit atomic claims and preserves triangle correspondence order', () => {
  assert.equal(parseAtomicStatement('△ABC∽△DEF')?.fact, 'similar(ABC,DEF)');
  assert.equal(parseAtomicStatement('△ABC≡△DEF')?.fact, 'congruent(ABC,DEF)');
  assert.equal(parseAtomicStatement('∠ABC=∠DEF')?.fact, 'angle(ABC)=angle(DEF)');
  assert.equal(parseAtomicStatement('PA=PC')?.fact, 'side(AP)=side(CP)');
  assert.equal(parseAtomicStatement('文字だけの説明'), null);
});

test('stepwise audit proves AA similarity from two explicit angle equalities', () => {
  const problem = {
    given_conditions: [
      { type: 'angle_equal', statement: '∠ABC=∠DEF' },
      { type: 'angle_equal', statement: '∠ACB=∠DFE' }
    ],
    geometry: { triangles: [{ vertices: ['A', 'B', 'C'] }, { vertices: ['D', 'E', 'F'] }] },
    proof: { target: '△ABC∽△DEF', steps: ['∠ABC=∠DEF', '∠ACB=∠DFE', 'よって△ABC∽△DEF'] }
  };
  const result = auditStructuredProof(problem);
  assert.equal(result.engine_available, true);
  assert.equal(result.proof_group_count, 1);
  assert.equal(result.groups[0].target_result.status, 'proved-in-step-sequence');
  assert.equal(result.groups[0].trace[2].claims[0].status, 'proved-from-accepted-facts');
});

test('does not accept a conclusion that is not derivable from available facts', () => {
  const problem = {
    given_conditions: [],
    geometry: { triangles: [{ vertices: ['A', 'B', 'C'] }, { vertices: ['D', 'E', 'F'] }] },
    proof: { target: '△ABC∽△DEF', steps: ['よって△ABC∽△DEF'] }
  };
  const result = auditStructuredProof(problem);
  assert.equal(result.groups[0].trace[0].accepted, false);
  assert.equal(result.groups[0].target_result.status, 'not-proved-with-current-rules');
  assert.equal(result.groups[0].accepted_fact_count, 2); // only structural triangle declarations
});

test('checks both claims in a chained equality instead of accepting only the first', () => {
  const claims = parseAtomicStatements('BF=AD=EC');
  assert.equal(claims.length, 2);
  assert.deepEqual(claims.map(x => x.text), ['BF=AD', 'AD=EC']);
});

test('all seven past-problem JSON files produce a conservative step audit without throwing', async () => {
  for (const year of [2014, 2015, 2016, 2017, 2024, 2025, 2026]) {
    const problem = await loadYear(year);
    const result = auditStructuredProof(problem);
    assert.ok(result.proof_group_count >= 1, `${year}: no proof groups found`);
    for (const group of result.groups) {
      assert.equal(group.trace.length, group.step_count, `${year}/${group.id}: trace length mismatch`);
      assert.ok(group.target_result.status);
      for (const step of group.trace) {
        if (step.accepted && step.claims) assert.ok(step.claims.every(claim => claim.accepted), `${year}/${group.id}: accepted step contains rejected claim`);
      }
    }
  }
});


test('integrates the structured audit into the existing problem audit report', () => {
  const report = auditGeneratedProblem({
    given_conditions: [
      { type: 'angle_equal', statement: '∠ABC=∠DEF' },
      { type: 'angle_equal', statement: '∠ACB=∠DFE' }
    ],
    geometry: { triangles: [{ vertices: ['A', 'B', 'C'] }, { vertices: ['D', 'E', 'F'] }] },
    proof: { target: '△ABC∽△DEF', steps: ['∠ABC=∠DEF', '∠ACB=∠DFE', '△ABC∽△DEF'] }
  });
  assert.equal(report.symbolic_verification_status, 'verified');
  assert.equal(report.symbolic_proof_audit.fully_proved_group_count, 1);
});


test('does not leak P2-only assumptions into the P1 proof audit', () => {
  const problem = {
    given_conditions: [
      { type: 'angle_equality', part: 'P2', statement: '∠ABC=∠DEF' },
      { type: 'angle_equality', part: 'P2', statement: '∠ACB=∠DFE' }
    ],
    geometry: { triangles: [{ vertices: ['A', 'B', 'C'] }, { vertices: ['D', 'E', 'F'] }] },
    proof: { target: '△ABC∽△DEF', steps: ['△ABC∽△DEF'] }
  };
  const result = auditStructuredProof(problem);
  assert.equal(result.groups[0].initial_fact_count, 0);
  assert.equal(result.groups[0].target_result.status, 'not-proved-with-current-rules');
});


test('derives the equal angles licensed by an explicit angle-bisector condition', () => {
  const problem = {
    given_conditions: [{ type: 'angle_bisector', objects: ['B', 'BD', 'ABC'], statement: 'BDは∠ABCの二等分線' }],
    geometry: { triangles: [{ vertices: ['A', 'B', 'C'] }] },
    proof: { target: '∠ABD=∠DBC', steps: ['∠ABD=∠DBC'] }
  };
  const result = auditStructuredProof(problem);
  assert.equal(result.groups[0].trace[0].status, 'all-claims-proved');
  assert.equal(result.groups[0].target_result.status, 'proved-in-step-sequence');
  const negative = globalThis.ProofRules.prove([], 'angle(ABD)=angle(DBC)');
  assert.equal(negative.success, false);
  assert.equal(globalThis.ProofRules.getTheorem('angle.bisector-definition').name, '角の二等分線の定義');
});


test('audits source derived_facts independently and never trusts reason/derived_from metadata as proof', async () => {
  const problem = await loadYear(2017);
  const result = auditStructuredProof(problem);
  const first = result.derived_fact_audit.trace.find(item => item.id === 'F01');
  const arcFact = result.derived_fact_audit.trace.find(item => item.id === 'F02');
  assert.equal(first.accepted, true);
  assert.equal(first.status, 'all-claims-proved');
  assert.equal(arcFact.accepted, false);
  assert.equal(arcFact.status, 'unsupported-statement');
  assert.ok(result.derived_fact_audit.unproved_count + result.derived_fact_audit.unsupported_count > 0);
});
