import test from 'node:test';
import assert from 'node:assert/strict';
import { generateAutoProblem, generateProblem, TEMPLATE_CATALOG } from '../../js/problem_generator.js';
import { auditDifficultyContract } from '../../js/difficulty_engine.js';

const template2017 = TEMPLATE_CATALOG.find(template => template.year === 2017);

test('difficulty audit reports proof structure dimensions without overstating absolute difficulty', () => {
  const problem = generateProblem(template2017.id, { seed: 20261011, difficulty: 8 });
  const audit = problem.generation.difficulty_audit;
  assert.equal(audit.status, 'passed');
  assert.equal(audit.dimensions.calculation_form, 'radical-fraction');
  assert.ok(audit.dimensions.source_proof_steps > 0);
  assert.ok(audit.dimensions.formal_derivation_depth > 0);
  assert.ok(audit.dimensions.distinct_inference_rules > 0);
  assert.match(audit.limitation, /絶対的な難しさ/u);
});

test('decimal answers and wrong radical forms fail the difficulty contract', () => {
  const problem = generateProblem(template2017.id, { seed: 1, difficulty: 8 });
  const decimal = structuredClone(problem);
  decimal.problem.parts[1].target.answer = '2.7320508';
  decimal.follow_up.P2.answer = '2.7320508';
  assert.equal(auditDifficultyContract(decimal, 8).valid, false);
  const wrong = structuredClone(problem);
  wrong.problem.parts[1].target.answer = '2+√3';
  wrong.follow_up.P2.answer = '2+√3';
  assert.equal(auditDifficultyContract(wrong, 8).valid, false);
});

test('levels 3-5 allow templates without a separate numeric follow-up', () => {
  const problem = generateAutoProblem({ seed: 20261011, filters: { difficulty: '3' } });
  assert.equal(problem.generation.difficulty_audit.valid, true);
  assert.equal(problem.generation.difficulty_audit.dimensions.calculation_form, 'not-applicable');
});

test('all requested levels produce a difficulty contract report', () => {
  for (let level = 3; level <= 8; level++) {
    const problem = generateAutoProblem({ seed: 20261011 + level, filters: { difficulty: String(level) } });
    assert.equal(problem.generation.difficulty, level);
    assert.equal(problem.validation.difficulty_contract.valid, true);
    assert.equal(problem.generation.difficulty_audit.status, 'passed');
  }
});


test('strict automatic difficulty contract rejects a mismatched year family', () => {
  const problem = generateProblem(template2017.id, { seed: 3, difficulty: 5 });
  const report = auditDifficultyContract(problem, 3, { strictFamily: true });
  assert.equal(report.valid, false);
  assert.ok(report.errors.some(error => error.includes('生成対象年度')));
});

test('shortened proof source fails the proof-stage contract', () => {
  const problem = generateProblem(template2017.id, { seed: 3, difficulty: 5 });
  problem.proof.steps = ['結論だけ'];
  const report = auditDifficultyContract(problem, 5);
  assert.equal(report.valid, false);
  assert.ok(report.errors.some(error => error.includes('論理段階が不足')));
});
