import test from 'node:test';
import assert from 'node:assert/strict';
import { TEMPLATE_CATALOG } from '../../js/template_registry.js';
import { generateProblem } from '../../js/problem_generator.js';
import {
  FORMAL_RULE_CATALOG,
  createProofFirstConstructionPlan,
  verifyFormalProofCertificate
} from '../../js/formal_proof_system.js';
import { verifyProblemMathematics } from '../../js/independent_math_verifier.js';

test('formal theorem registry has stable, named rules and every supported year has a proof-first schema', () => {
  assert.ok(Object.keys(FORMAL_RULE_CATALOG).length >= 20);
  for (const template of TEMPLATE_CATALOG) {
    const plan = createProofFirstConstructionPlan(template.id);
    assert.equal(plan.year, template.year);
    assert.equal(plan.construction_allowed, true);
    assert.ok(plan.derivation.length >= 3);
    assert.ok(plan.target);
  }
});

test('all seven year templates produce a condition-matched formal schema certificate', () => {
  for (const template of TEMPLATE_CATALOG) {
    const problem = generateProblem(template.id, { seed: 20261011 });
    const certificate = verifyFormalProofCertificate(problem);
    assert.equal(certificate.status, 'schema-verified', `${template.year}: ${certificate.errors.join('; ')}`);
    assert.equal(certificate.valid, true);
    assert.equal(problem.validation.proof_first_preflight.construction_allowed, true);
    assert.equal(problem.validation.independent_math_audit.layers.formal_certificate.valid, true);
  }
});

test('formal certificate fails closed when target or required givens are corrupted', () => {
  const template = TEMPLATE_CATALOG.find(t => t.year === 2026);
  const targetMutation = generateProblem(template.id, { seed: 11 });
  targetMutation.proof.target = '△AFC∽△DBC';
  assert.equal(verifyFormalProofCertificate(targetMutation).status, 'failed');

  const conditionMutation = generateProblem(template.id, { seed: 12 });
  conditionMutation.given_conditions = conditionMutation.given_conditions.filter(c => c.id !== 'C03');
  const report = verifyFormalProofCertificate(conditionMutation);
  assert.equal(report.status, 'failed');
  assert.ok(report.errors.some(e => e.includes('C03')));
});

test('unknown templates are not accepted by proof-first construction', () => {
  assert.throws(() => createProofFirstConstructionPlan('UNKNOWN_TEMPLATE'), /形式化された証明計画/);
});

test('regression: 30 seeds per supported year preserve certificate and reject no valid generated instance', () => {
  for (const template of TEMPLATE_CATALOG) {
    for (let seed = 0; seed < 30; seed++) {
      const problem = generateProblem(template.id, { seed: seed + 1000 });
      const cert = verifyFormalProofCertificate(problem);
      assert.equal(cert.valid, true, `${template.year}, seed ${seed}: ${cert.errors.join('; ')}`);
      assert.equal(problem.validation.independent_math_audit.status, 'verified', `${template.year}, seed ${seed}: ${problem.validation.independent_math_audit.errors.join('; ')} / ${problem.validation.independent_math_audit.warnings.join('; ')}`);
    }
  }
});


test('independent proof-conclusion checker rejects corrupted coordinates', () => {
  const template = TEMPLATE_CATALOG.find(t => t.year === 2026);
  const problem = generateProblem(template.id, { seed: 42 });
  const p = problem.geometry.coordinates.variants.P1.points.F;
  p.x += 0.23;
  p.y -= 0.17;
  problem.geometryModel.points.F.x = p.x;
  problem.geometryModel.points.F.y = p.y;
  const certificate = verifyFormalProofCertificate(problem);
  assert.equal(certificate.status, 'failed');
  assert.ok(certificate.numeric_audit.failed_count > 0);
  assert.equal(verifyProblemMathematics(problem).status, 'failed');
});
