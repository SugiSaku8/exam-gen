import test from 'node:test';
import assert from 'node:assert/strict';
import { generateProblem } from '../../js/problem_generator.js';
import { TEMPLATE_CATALOG } from '../../js/template_registry.js';
import { generateAnswerModel } from '../../js/answer_generator.js';

test('all supported year templates generate deterministic geometry-backed problems and answers', () => {
  for (const template of TEMPLATE_CATALOG) {
    const problem = generateProblem(template.id, { seed: 42 });
    const answer = generateAnswerModel(problem);
    assert.equal(problem.metadata.year, template.year);
    assert.ok(problem.given_conditions?.length, `${template.year}: conditions`);
    assert.ok(answer.target, `${template.year}: proof target`);
    assert.ok(answer.steps.length >= 3, `${template.year}: proof steps`);
    assert.ok(answer.followup?.answer, `${template.year}: follow-up answer`);
  }
});
