import test from 'node:test';
import assert from 'node:assert/strict';
import { generateProblem, TEMPLATE_CATALOG } from '../../js/problem_generator.js';
import { verifyProblemMathematics, buildProofFirstSpecification, generateFromProofFirstPlan } from '../../js/independent_math_verifier.js';

test('every supported template receives a conservative independent math certificate', () => {
  for (const template of TEMPLATE_CATALOG) {
    const problem = generateProblem(template.id, { seed: 42 });
    const report = problem.validation.independent_math_audit;
    assert.ok(report, `${template.year}: certificate exists`);
    assert.equal(report.independent, true);
    assert.ok(['verified', 'partial', 'failed', 'not-verifiable'].includes(report.status));
    if (report.status !== 'verified') assert.equal(report.mathematically_verified, false, `${template.year}: no false positive`);
  }
});

test('proof-first specification lists referenced conditions and detects missing dependencies', () => {
  const p = {
    given_conditions: [{ id: 'C01', statement: 'AB=AC' }],
    derived_facts: [{ id: 'F01', statement: '∠ABC=∠BCA', reason: ['C01'] }],
    proof: { target: 'AB=AC', proof_graph: [['C01', 'F01']], steps: ['AB=AC'] }
  };
  const spec = buildProofFirstSpecification(p);
  assert.deepEqual(spec.required_condition_ids, ['C01']);
  assert.equal(spec.ready_for_geometry_construction, true);
  p.proof.proof_graph.push(['C99', 'F01']);
  assert.deepEqual(buildProofFirstSpecification(p).required_condition_ids, ['C01', 'C99']);
  assert.deepEqual(buildProofFirstSpecification(p).missing_condition_ids, ['C99']);
  assert.equal(buildProofFirstSpecification(p).ready_for_geometry_construction, false);
});

test('independent coordinate verifier rejects a deliberately corrupted answer', () => {
  const template = TEMPLATE_CATALOG.find(t => t.year === 2026);
  const problem = generateProblem(template.id, { seed: 42 });
  problem.follow_up.answer = '67°';
  problem.problem.statement.parts.find(p => p.id === 'P2').answer = '67°';
  const report = verifyProblemMathematics(problem);
  assert.equal(report.status, 'failed');
  assert.ok(report.layers.geometry.errors.some(x => x.includes('P2答案')));
});

test('unsupported proof steps are never upgraded to verified solely by valid coordinates', () => {
  const template = TEMPLATE_CATALOG.find(t => t.year === 2026);
  const problem = generateProblem(template.id, { seed: 42 });
  problem.proof.steps = ['図を見れば明らかである'];
  problem.proof.P1 = undefined;
  const report = verifyProblemMathematics(problem);
  assert.notEqual(report.status, 'verified');
  assert.equal(report.mathematically_verified, false);
});

test('proof-first constructor proves the target from givens before invoking geometry construction', () => {
  let constructorCalled = false;
  const givens = [
    { id: 'C01', statement: '△ABCは三角形', fact: 'triangle(ABC)' },
    { id: 'C02', statement: '△DEFは三角形', fact: 'triangle(DEF)' },
    { id: 'C03', statement: '∠ABC=∠DEF', fact: 'angle(ABC)=angle(DEF)' },
    { id: 'C04', statement: '∠ACB=∠DFE', fact: 'angle(ACB)=angle(DFE)' }
  ];
  const result = generateFromProofFirstPlan({
    target: 'similar(ABC,DEF)', givens,
    steps: [{ id: 'S01', premises: givens.map(g => g.fact), conclusion: 'similar(ABC,DEF)' }]
  }, ({ target, givens: acceptedGivens, steps }) => {
    constructorCalled = true;
    return { given_conditions: acceptedGivens.map(g => ({ id: g.id, statement: g.statement })), proof: { target, steps: steps.map(s => ({ statement: s.conclusion })) } };
  });
  assert.equal(constructorCalled, true);
  assert.equal(result.proof_first_plan.target, 'similar(ABC,DEF)');
  assert.equal(result.proof_first_plan.steps[0].accepted, true);
});
