import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { generateAnswerModel } from '../../js/answer_generator.js';

for (const year of [2014, 2015, 2016, 2017, 2024, 2025, 2026]) {
  test(`${year} source data generates a deterministic proof answer and follow-up`, () => {
    const data = JSON.parse(fs.readFileSync(new URL(`../../data/${year}.json`, import.meta.url), 'utf8'));
    const answer = generateAnswerModel(data);
    assert.ok(answer.target, `${year}: proof target should be found`);
    assert.ok(answer.steps.length >= 3, `${year}: proof steps should be generated`);
    assert.ok(answer.followup?.answer !== undefined, `${year}: follow-up answer should be found`);
    assert.ok(answer.followup.prompt, `${year}: follow-up prompt should be found`);
    assert.deepEqual(generateAnswerModel(data), answer, `${year}: answer generation should be deterministic`);
  });
}
