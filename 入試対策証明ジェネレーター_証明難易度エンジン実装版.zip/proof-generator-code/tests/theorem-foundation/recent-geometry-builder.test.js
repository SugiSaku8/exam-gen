import test from 'node:test';
import assert from 'node:assert/strict';
import { generate2024, generate2025, generate2026 } from '../../js/templates/recent_generators.js';

const generators = [[2024, generate2024], [2025, generate2025], [2026, generate2026]];

test('2024-2026 generators reconstruct coordinates from constraints and pass their built-in checks', () => {
  for (const [year, generate] of generators) {
    for (const seed of [1, 4, 7, 12, 18]) {
      const problem = generate({ seed });
      assert.equal(problem.validation.geometry.valid, true, `${year}/${seed}: ${problem.validation.geometry.errors.join('; ')}`);
      assert.ok(problem.validation.geometry.checks.length >= 8);
      assert.equal(problem.metadata.data_status, 'generated_variant');
      assert.notEqual(problem.metadata.id, problem.metadata.source_problem_id);
      assert.equal(problem.geometry.coordinate_system.status, 'reconstructed_from_constraints');
      assert.ok(problem.geometryModel.points.P, `${year}/${seed}: P missing from GeometryModel`);
      assert.equal(problem.geometryModel.constraints.valid, true);
    }
  }
});

test('2024 family updates its stated arc ratio, angle, and answer together', () => {
  const problem = generate2024({ seed: 7 });
  assert.equal(problem.given_conditions.find(c => c.id === 'C09').statement, 'arc BC : arc CE = 3:4');
  assert.equal(problem.given_conditions.find(c => c.id === 'C10').statement, '∠CFD=55°');
  assert.equal(problem.follow_up.answer, '75°');
  assert.equal(problem.problem.statement.parts.find(p => p.id === 'P2').answer, '75°');
});

test('2025 family reconstructs E, F, G and formats exact arc length with pi in standard form', () => {
  const problem = generate2025({ seed: 7 });
  assert.equal(problem.given_conditions.find(c => c.id === 'C09').statement, '∠FEB=65°');
  assert.equal(problem.given_conditions.find(c => c.id === 'C10').statement, 'radius O=9 cm');
  assert.equal(problem.follow_up.answer, '4π cm');
  assert.ok(problem.geometry.coordinates.variants.P1.points.G);
  assert.ok(problem.geometry.coordinates.variants.P2.points.G);
});

test('2026 family varies arc length, reconstructs the parallel-chord geometry, and updates answer', () => {
  const problem = generate2026({ seed: 4 });
  assert.equal(problem.given_conditions.find(c => c.id === 'C09').statement, 'arc BC=9π cm');
  assert.equal(problem.follow_up.answer, '63°');
  assert.equal(problem.problem.statement.parts.find(p => p.id === 'P2').answer, '63°');
});

test('seeds produce structurally distinct geometries, not only rigid transforms', () => {
  for (const [year, generate] of generators) {
    const a = generate({ seed: 1 });
    const b = generate({ seed: 7 });
    const pA = a.geometry.coordinates.points.C;
    const pB = b.geometry.coordinates.points.C;
    const keyA = `${pA.x},${pA.y}`;
    const keyB = `${pB.x},${pB.y}`;
    assert.notEqual(keyA, keyB, `${year}: expected a different C placement for the selected seeds`);
  }
});
