import test from 'node:test';
import assert from 'node:assert/strict';
import { generate2024, generate2025, generate2026 } from '../../js/templates/recent_generators.js';
import { validateProblemGeometry } from '../../js/geometry_validator.js';
import { generateProblem } from '../../js/problem_generator.js';

const cases = [
  [2024, generate2024, 'SHIZUOKA_CIRCLE_ISOSCELES_MOVING_POINT_ISOSCELES_2024_001'],
  [2025, generate2025, 'SHIZUOKA_CIRCLE_ISOSCELES_PARALLEL_SIMILARITY_2025_001'],
  [2026, generate2026, 'SHIZUOKA_CIRCLE_ISOSCELES_PARALLEL_CONGRUENCE_2026_001']
];

test('independent geometry validator recalculates generated constraints from coordinates', () => {
  for (const [year, generate] of cases) {
    for (const seed of [1, 4, 7, 12, 18]) {
      const problem = generate({ seed });
      const result = validateProblemGeometry(problem);
      assert.equal(result.status, 'validated', `${year}/${seed}: ${result.errors.join('; ')}`);
      assert.equal(result.failed_count, 0);
      assert.ok(result.check_count >= 40);
    }
  }
});

test('independent validator detects a corrupted coordinate even if builder checks still claim valid', () => {
  const problem = generate2026({ seed: 1 });
  problem.geometry.coordinates.variants.P1.points.P.x += 0.15;
  assert.equal(problem.validation.geometry.valid, true); // builder's old report is unchanged
  const result = validateProblemGeometry(problem);
  assert.equal(result.valid, false);
  assert.ok(result.errors.length > 0);
});

test('independent validator detects a stale or incorrect numerical answer', () => {
  const problem = generate2025({ seed: 12 });
  problem.problem.statement.parts.find(p => p.id === 'P2').answer = '1π cm';
  const result = validateProblemGeometry(problem);
  assert.equal(result.valid, false);
  assert.ok(result.errors.some(e => e.includes('P2答案')));
});

test('problem generation pipeline stores independent geometry audit alongside proof audit', () => {
  const problem = generateProblem('SHIZUOKA_CIRCLE_ISOSCELES_PARALLEL_CONGRUENCE_2026_001', { seed: 1 });
  assert.equal(problem.validation.independent_geometry_audit.status, 'validated');
  assert.equal(problem.validation.independent_geometry_audit.valid, true);
  assert.ok(problem.validation.theorem_audit.symbolic_proof_audit);
});
