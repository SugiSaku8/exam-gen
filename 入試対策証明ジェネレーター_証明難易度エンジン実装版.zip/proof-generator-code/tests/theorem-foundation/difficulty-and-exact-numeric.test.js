import test from 'node:test';
import assert from 'node:assert/strict';
import { generateAutoProblem, generateProblem, TEMPLATE_CATALOG } from '../../js/problem_generator.js';
import { generateAnswerModel } from '../../js/answer_generator.js';
import { readFileSync } from 'node:fs';

const template2017 = TEMPLATE_CATALOG.find(template => template.year === 2017);

function numericAnswer(problem) {
  return String(problem.problem?.parts?.[1]?.target?.answer ?? problem.follow_up?.P2?.answer ?? '');
}

test('visible UI no longer contains the mathematical-verification badge', () => {
  const html = readFileSync(new URL('../../index.html', import.meta.url), 'utf8');
  const main = readFileSync(new URL('../../main.js', import.meta.url), 'utf8');
  assert.doesNotMatch(html, /verification-badge|数学検証済|数学検証:未判定/);
  assert.doesNotMatch(main, /verification-badge|数学検証済/);
});

test('selected difficulty is a hard constraint rather than a nearest-match preference', () => {
  const expectedYearGroups = {
    3: [2014, 2015],
    4: [2016],
    5: [2017, 2024, 2025, 2026],
    6: [2017],
    7: [2017],
    8: [2017]
  };
  for (let difficulty = 3; difficulty <= 8; difficulty++) {
    const problem = generateAutoProblem({ seed: 20261011, filters: { difficulty: String(difficulty) } });
    assert.equal(problem.generation.difficulty, difficulty);
    assert.ok(expectedYearGroups[difficulty].includes(problem.metadata.year), `difficulty ${difficulty} unexpectedly selected ${problem.metadata.year}`);
    assert.ok(problem.generation.difficulty_profile);
    assert.equal(problem.validation.independent_geometry_audit.valid, true);
    assert.notEqual(problem.validation.independent_math_audit.status, 'failed');
  }
});

test('numerical answer complexity follows the selected level and never falls back to decimals', () => {
  const expected = {
    3: '4',
    4: '6',
    5: '6',
    6: '2+√3',
    7: '(3+2√3)/3',
    8: '(2+3√3)/2'
  };
  for (let difficulty = 3; difficulty <= 8; difficulty++) {
    const problem = generateProblem(template2017.id, { seed: 20261011, difficulty });
    const answer = numericAnswer(problem);
    assert.equal(answer, expected[difficulty], `difficulty ${difficulty}`);
    assert.doesNotMatch(answer, /\d+\.\d+/u, `decimal answer is forbidden at difficulty ${difficulty}`);
    assert.equal(problem.problem.parts[1].target.answer, problem.follow_up.P2.answer);
    assert.equal(problem.validation.independent_geometry_audit.valid, true);
    assert.notEqual(problem.validation.independent_math_audit.status, 'failed');
  }
});

test('hardest numerical form is a fraction whose numerator is a+b√c', () => {
  const problem = generateAutoProblem({ seed: 20261011, filters: { difficulty: '8' } });
  const answer = numericAnswer(problem);
  assert.match(answer, /^\(\d+\+\d+√\d+\)\/\d+$/u);
  assert.doesNotMatch(answer, /\d+\.\d+/u);
  assert.match(problem.problem.parts[1].question, /AD\+3AE/u);
});


test('high-difficulty answer explanation matches the actual generated question', () => {
  for (const difficulty of [6, 7, 8]) {
    const problem = generateProblem(template2017.id, { seed: 20261011, difficulty });
    const model = generateAnswerModel(problem);
    assert.ok(model.followup);
    assert.match(model.followup.prompt, /AD\+/u);
    assert.equal(model.followup.answer, numericAnswer(problem));
    assert.ok(model.followup.steps.length >= 2);
    assert.doesNotMatch(model.followup.steps.map(step => step.statement).join(' '), /\[CDE\]\/\[DGE\]/u);
    assert.match(model.followup.unit, /cm/u);
  }
});


test('unrestricted generation still receives a valid difficulty instead of NaN', () => {
  const problem = generateAutoProblem({ seed: 123, filters: { difficulty: 'all' } });
  assert.ok(Number.isInteger(problem.generation.difficulty));
  assert.ok(problem.generation.difficulty >= 3 && problem.generation.difficulty <= 8);
});


test('conflicting difficulty and proof-type settings fail closed instead of silently changing the requested type', () => {
  assert.throws(
    () => generateAutoProblem({ seed: 7, filters: { difficulty: '8', proofType: 'congruence' } }),
    /対応する問題テンプレートがありません/u
  );
});
